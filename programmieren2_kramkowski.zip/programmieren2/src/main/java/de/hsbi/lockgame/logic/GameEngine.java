package de.hsbi.lockgame.logic;

import de.hsbi.lockgame.model.Direction;
import de.hsbi.lockgame.model.Level;
import de.hsbi.lockgame.model.Snake;
import de.hsbi.lockgame.ui.GamePanel;
import java.util.List;

public final class GameEngine {

    private GameState state;
    private GamePanel panel;

    public GameEngine(Level level) {
        // Initialer Zustand mit Startposition aus Level
        Snake snake = new Snake(List.of(level.snakeStart()));

        this.state =
            new GameState(
                level,
                snake,
                level.pins(),
                GameState.Status.RUNNING,
                Direction.NONE);
    }

    public GameState state() {
        return state;
    }

    public void setGamePanel(GamePanel panel) {
        this.panel = panel;
    }

    public void update(Direction d) {
        // Gegenrichtung verhindern
        if (d == state.pendingDirection().oppositeDirection()) {
            return;
        }

        state =
            new GameState(
                state.level(),
                state.snake(),
                state.pins(),
                state.status(),
                d);

        // Observer benachrichtigen (Methodenreferenz)
        java.util.Optional.ofNullable(panel).ifPresent(p -> p.update(state));
    }

    public void tick() {
        state = state.tick();

        // Observer benachrichtigen (Methodenreferenz)
        java.util.Optional.ofNullable(panel).ifPresent(p -> p.update(state));
    }
}
