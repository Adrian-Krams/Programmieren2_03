package de.hsbi.lockgame.logic;

import de.hsbi.lockgame.model.*;
import java.util.List;

public final class GameState {

    private final Level level;
    private final Snake snake;
    private final List<Pin> pins;
    private final Status status;
    private final Direction pendingDirection;

    public GameState(
        Level level, Snake snake, List<Pin> pins, Status status, Direction pendingDirection) {
        // TODO: lege einen neuen GameState mit den übergebenen Informationen an
        this.level = level;
        this.snake = snake;
        this.pins = pins;
        this.status = status;
        this.pendingDirection = pendingDirection;
    }

    public Level level() {
        // TODO: Getter
        return level;
    }

    public Snake snake() {
        // TODO: Getter
        return snake;
    }

    public List<Pin> pins() {
        // TODO: Getter
        return pins;
    }

    public Status status() {
        // TODO: Getter
        return status;
    }

    public Direction pendingDirection() {
        // TODO: Getter
        return pendingDirection;
    }

    public GameState tick() {
        if (!status.isRunning() || pendingDirection == Direction.NONE) {
            return this;
        }

        Position nextPos = snake.nextHead(pendingDirection);

        // (a) Out of bounds
        if (!level.isInside(nextPos)) {
            return new GameState(level, snake, pins, Status.LOST_OUT_OF_BOUNDS, Direction.NONE);
        }

        // (b) Wand
        if (level.cellAt(nextPos) == CellType.WALL) {
            return new GameState(level, snake, pins, status, Direction.NONE);
        }

        // (c) Selbstkollision
        if (snake.occupies(nextPos)) {
            return new GameState(level, snake, pins, Status.LOST_SELF_COLLISION, Direction.NONE);
        }

        // (d) Pin prüfen
        for (int i = 0; i < pins.size(); i++) {
            Pin pin = pins.get(i);

            if (pin.position().x() == nextPos.x() && pin.position().y() == nextPos.y()) {

                // Pin schon gesetzt oder falsche Richtung -> blockiert
                if (pin.state().isSet() || pin.activationDirection() != pendingDirection) {
                    return new GameState(level, snake, pins, status, Direction.NONE);
                }

                // Richtiger Pin -> aktivieren, aber nicht betreten
                var newPins = new java.util.ArrayList<>(pins);
                newPins.set(i, pin.withState(Pin.State.HIGH));

                boolean allSet = newPins.stream().map(Pin::state).allMatch(Pin.State::isSet);

                return new GameState(
                    level,
                    snake,
                    newPins,
                    allSet ? Status.WON : status,
                    Direction.NONE);
            }
        }

        // Normale Bewegung
        Snake newSnake = snake.grow(pendingDirection);

        return new GameState(level, newSnake, pins, status, pendingDirection);
    }

    public enum Status {
        RUNNING,
        WON,
        LOST_SELF_COLLISION,
        LOST_OUT_OF_BOUNDS;

        public boolean isRunning() {
            return this == RUNNING;
        }
    }
}
