package de.hsbi.lockgame.logic;

import static org.junit.jupiter.api.Assertions.*;

import de.hsbi.lockgame.model.*;
import java.util.List;
import org.junit.jupiter.api.Test;

public class GameStateTest {

    private Level createEmptyLevel() {
        CellType[][] cells =
            new CellType[][] {
                {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY},
                {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY},
                {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY}
            };

        return new Level(3, 3, cells, List.of(), new Position(1, 1));
    }

    @Test
    void givenNoDirection_whenTick_thenStateDoesNotChange() {
        Level level = createEmptyLevel();
        Snake snake = new Snake(List.of(new Position(1, 1)));

        GameState state =
            new GameState(
                level,
                snake,
                List.of(),
                GameState.Status.RUNNING,
                Direction.NONE);

        GameState next = state.tick();

        assertEquals(state.snake().head(), next.snake().head());
    }

    @Test
    void givenFreePath_whenTick_thenSnakeMovesRight() {
        Level level = createEmptyLevel();
        Snake snake = new Snake(List.of(new Position(1, 1)));

        GameState state =
            new GameState(
                level,
                snake,
                List.of(),
                GameState.Status.RUNNING,
                Direction.RIGHT);

        GameState next = state.tick();

        assertEquals(new Position(2, 1), next.snake().head());
    }

    @Test
    void givenWall_whenTick_thenSnakeDoesNotMove() {
        CellType[][] cells =
            new CellType[][] {
                {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY},
                {CellType.EMPTY, CellType.WALL, CellType.EMPTY},
                {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY}
            };

        Level level = new Level(3, 3, cells, List.of(), new Position(1, 0));
        Snake snake = new Snake(List.of(new Position(1, 0)));

        GameState state =
            new GameState(
                level,
                snake,
                List.of(),
                GameState.Status.RUNNING,
                Direction.DOWN);

        GameState next = state.tick();

        assertEquals(new Position(1, 0), next.snake().head());
    }

    @Test
    void givenOutOfBounds_whenTick_thenGameIsLost() {
        Level level = createEmptyLevel();
        Snake snake = new Snake(List.of(new Position(2, 1)));

        GameState state =
            new GameState(
                level,
                snake,
                List.of(),
                GameState.Status.RUNNING,
                Direction.RIGHT);

        GameState next = state.tick();

        assertEquals(GameState.Status.LOST_OUT_OF_BOUNDS, next.status());
    }
    @Test
    void givenSelfCollision_whenTick_thenGameIsLost() {
        Snake snake =
            new Snake(
                List.of(
                    new Position(1, 1),
                    new Position(1, 2),
                    new Position(0, 2),
                    new Position(0, 1)));

        Level level = createEmptyLevel();

        GameState state =
            new GameState(
                level,
                snake,
                List.of(),
                GameState.Status.RUNNING,
                Direction.LEFT);

        GameState next = state.tick();

        assertEquals(GameState.Status.LOST_SELF_COLLISION, next.status());
    }

    @Test
    void givenLostGame_whenTick_thenNothingChanges() {
        Level level = createEmptyLevel();
        Snake snake = new Snake(List.of(new Position(1, 1)));

        GameState state =
            new GameState(
                level,
                snake,
                List.of(),
                GameState.Status.LOST_OUT_OF_BOUNDS,
                Direction.RIGHT);

        GameState next = state.tick();

        assertEquals(state.status(), next.status());
        assertEquals(state.snake().head(), next.snake().head());
    }
    @Test
    void givenCorrectPinDirection_whenTick_thenPinIsActivated() {
        Pin pin = new Pin(new Position(2, 1), Pin.State.LOW, Direction.RIGHT);

        Level level =
            new Level(
                3,
                3,
                new CellType[][] {
                    {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY},
                    {CellType.EMPTY, CellType.EMPTY, CellType.PIN_SLOT},
                    {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY}
                },
                List.of(pin),
                new Position(1, 1));

        Snake snake = new Snake(List.of(new Position(1, 1)));

        GameState state =
            new GameState(
                level,
                snake,
                List.of(pin),
                GameState.Status.RUNNING,
                Direction.RIGHT);

        GameState next = state.tick();

        assertTrue(next.pins().get(0).state().isSet());
        assertEquals(new Position(1, 1), next.snake().head());
    }

    @Test
    void givenWrongPinDirection_whenTick_thenSnakeIsBlocked() {
        Pin pin = new Pin(new Position(2, 1), Pin.State.LOW, Direction.LEFT);

        Level level =
            new Level(
                3,
                3,
                new CellType[][] {
                    {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY},
                    {CellType.EMPTY, CellType.EMPTY, CellType.PIN_SLOT},
                    {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY}
                },
                List.of(pin),
                new Position(1, 1));

        Snake snake = new Snake(List.of(new Position(1, 1)));

        GameState state =
            new GameState(
                level,
                snake,
                List.of(pin),
                GameState.Status.RUNNING,
                Direction.RIGHT);

        GameState next = state.tick();

        assertEquals(new Position(1, 1), next.snake().head());
        assertFalse(next.pins().get(0).state().isSet());
    }

    @Test
    void givenAlreadyActivatedPin_whenTick_thenSnakeIsBlocked() {
        Pin pin = new Pin(new Position(2, 1), Pin.State.HIGH, Direction.RIGHT);

        Level level =
            new Level(
                3,
                3,
                new CellType[][] {
                    {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY},
                    {CellType.EMPTY, CellType.EMPTY, CellType.PIN_SLOT},
                    {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY}
                },
                List.of(pin),
                new Position(1, 1));

        Snake snake = new Snake(List.of(new Position(1, 1)));

        GameState state =
            new GameState(
                level,
                snake,
                List.of(pin),
                GameState.Status.RUNNING,
                Direction.RIGHT);

        GameState next = state.tick();

        assertEquals(new Position(1, 1), next.snake().head());
    }

    @Test
    void givenLastPinActivated_whenTick_thenGameIsWon() {
        Pin pin = new Pin(new Position(2, 1), Pin.State.LOW, Direction.RIGHT);

        Level level =
            new Level(
                3,
                3,
                new CellType[][] {
                    {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY},
                    {CellType.EMPTY, CellType.EMPTY, CellType.PIN_SLOT},
                    {CellType.EMPTY, CellType.EMPTY, CellType.EMPTY}
                },
                List.of(pin),
                new Position(1, 1));

        Snake snake = new Snake(List.of(new Position(1, 1)));

        GameState state =
            new GameState(
                level,
                snake,
                List.of(pin),
                GameState.Status.RUNNING,
                Direction.RIGHT);

        GameState next = state.tick();

        assertEquals(GameState.Status.WON, next.status());
    }
}
